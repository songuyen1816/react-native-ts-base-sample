export default {
    hello: 'Hello',
    no: 'No'
}