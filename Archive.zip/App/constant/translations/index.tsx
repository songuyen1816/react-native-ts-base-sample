import LocalizedStrings from "react-native-localization";
import english from './en'

export const strings = new LocalizedStrings({
    en: english
})