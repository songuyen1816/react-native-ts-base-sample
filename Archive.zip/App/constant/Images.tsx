export default Object.freeze({
    LOGO: require('../assets/img/logo.png')
})