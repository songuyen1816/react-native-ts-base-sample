export default Object.freeze({
    BLACK: '#2c3e50'
})