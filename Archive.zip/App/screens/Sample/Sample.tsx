import { View, Text } from 'react-native'
import React from 'react'

type Props = {}

const Sample = (props: Props) => {
    
  return (
    <View>
      <Text>Sample</Text>
    </View>
  )
}

export default Sample